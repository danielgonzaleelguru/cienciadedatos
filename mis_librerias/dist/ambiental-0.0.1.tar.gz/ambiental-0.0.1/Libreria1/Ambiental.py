def Suma(num1=0,num2=0):
    return num1+num2
